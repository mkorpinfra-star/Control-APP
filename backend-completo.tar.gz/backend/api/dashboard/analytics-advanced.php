<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once '../../config/database.php';
require_once '../../middleware/auth.php';

// Autenticação
$auth = authenticate();
if (!$auth['success']) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => $auth['error']]);
    exit;
}

$user = $auth['user'];

try {
    $pdo = getConnection();

    // Parâmetros
    $startDate = $_GET['start_date'] ?? date('Y-m-01'); // Primeiro dia do mês atual
    $endDate = $_GET['end_date'] ?? date('Y-m-t'); // Último dia do mês atual
    $obraId = isset($_GET['obra_id']) && $_GET['obra_id'] !== 'all' ? (int)$_GET['obra_id'] : null;
    $employeeId = isset($_GET['employee_id']) && $_GET['employee_id'] !== 'all' ? (int)$_GET['employee_id'] : null;

    // Comparação
    $compareStartDate = $_GET['compare_start_date'] ?? null;
    $compareEndDate = $_GET['compare_end_date'] ?? null;

    // ========================================
    // PERÍODO ATUAL
    // ========================================

    $whereConditions = ["a.status = 'aprovado'", "a.semana_inicio >= ?", "a.semana_inicio <= ?"];
    $params = [$startDate, $endDate];

    if ($obraId) {
        $whereConditions[] = "a.obra_id = ?";
        $params[] = $obraId;
    }

    if ($employeeId) {
        $whereConditions[] = "a.funcionario_id = ?";
        $params[] = $employeeId;
    }

    $whereClause = implode(' AND ', $whereConditions);

    // TOTAIS E CUSTOS
    $sql = "
        SELECT
            SUM(a.horas_normal) as total_normal,
            SUM(a.horas_extra) as total_extra,
            SUM(a.horas_noturna) as total_noturna,
            SUM(a.horas_total) as total_horas,
            COUNT(DISTINCT a.funcionario_id) as total_funcionarios,
            COUNT(DISTINCT a.obra_id) as total_obras,
            COUNT(*) as total_registros
        FROM apontamentos a
        WHERE $whereClause
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $totais = $stmt->fetch(PDO::FETCH_ASSOC);

    // Buscar valores configurados
    $valores = [
        'valor_hora_normal' => 21,
        'valor_hora_extra' => 28,
        'valor_hora_noturna' => 30
    ];

    $valoresStmt = $pdo->query("SELECT * FROM config WHERE chave IN ('valor_hora_normal', 'valor_hora_extra', 'valor_hora_noturna')");
    while ($row = $valoresStmt->fetch(PDO::FETCH_ASSOC)) {
        $valores[$row['chave']] = (float)$row['valor'];
    }

    $custoNormal = ($totais['total_normal'] ?? 0) * $valores['valor_hora_normal'];
    $custoExtra = ($totais['total_extra'] ?? 0) * $valores['valor_hora_extra'];
    $custoNoturna = ($totais['total_noturna'] ?? 0) * $valores['valor_hora_noturna'];
    $custoTotal = $custoNormal + $custoExtra + $custoNoturna;

    // TOP FUNCIONÁRIOS
    $sqlFuncionarios = "
        SELECT
            u.id,
            u.nome,
            SUM(a.horas_normal) as horas_normal,
            SUM(a.horas_extra) as horas_extra,
            SUM(a.horas_noturna) as horas_noturna,
            SUM(a.horas_total) as horas_total,
            COUNT(*) as registros
        FROM apontamentos a
        JOIN usuarios u ON a.funcionario_id = u.id
        WHERE $whereClause
        GROUP BY u.id, u.nome
        ORDER BY horas_total DESC
        LIMIT 20
    ";

    $stmt = $pdo->prepare($sqlFuncionarios);
    $stmt->execute($params);
    $funcionarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($funcionarios as &$func) {
        $func['custo_total'] =
            ($func['horas_normal'] * $valores['valor_hora_normal']) +
            ($func['horas_extra'] * $valores['valor_hora_extra']) +
            ($func['horas_noturna'] * $valores['valor_hora_noturna']);

        $func['eficiencia'] = $func['horas_total'] > 0
            ? (($func['horas_normal'] / $func['horas_total']) * 100)
            : 0;
    }

    // TOP OBRAS
    $sqlObras = "
        SELECT
            o.id,
            o.numero,
            o.nome,
            SUM(a.horas_total) as horas_total,
            SUM(a.horas_normal) as horas_normal,
            SUM(a.horas_extra) as horas_extra,
            SUM(a.horas_noturna) as horas_noturna,
            COUNT(DISTINCT a.funcionario_id) as total_funcionarios
        FROM apontamentos a
        JOIN obras o ON a.obra_id = o.id
        WHERE $whereClause
        GROUP BY o.id, o.numero, o.nome
        ORDER BY horas_total DESC
        LIMIT 10
    ";

    $stmt = $pdo->prepare($sqlObras);
    $stmt->execute($params);
    $obras = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($obras as &$obra) {
        $obra['custo_total'] =
            ($obra['horas_normal'] * $valores['valor_hora_normal']) +
            ($obra['horas_extra'] * $valores['valor_hora_extra']) +
            ($obra['horas_noturna'] * $valores['valor_hora_noturna']);
    }

    // EVOLUÇÃO TEMPORAL (últimos 7 períodos)
    $evol = [];
    $start = new DateTime($startDate);
    $end = new DateTime($endDate);
    $diff = $start->diff($end)->days;

    // Se período > 30 dias, agrupar por semana, senão por dia
    $groupBy = $diff > 30 ? 'week' : 'day';

    if ($groupBy === 'week') {
        // Agrupar por semana
        for ($i = 6; $i >= 0; $i--) {
            $weekEnd = clone $end;
            $weekEnd->modify("-{$i} weeks");
            $weekStart = clone $weekEnd;
            $weekStart->modify('-6 days');

            $sqlEvol = "
                SELECT
                    SUM(horas_normal) as normal,
                    SUM(horas_extra) as extra,
                    SUM(horas_noturna) as noturna,
                    SUM(horas_total) as total
                FROM apontamentos
                WHERE status = 'aprovado'
                AND semana_inicio >= ?
                AND semana_inicio <= ?
                " . ($obraId ? " AND obra_id = $obraId" : "") . "
                " . ($employeeId ? " AND funcionario_id = $employeeId" : "");

            $stmt = $pdo->prepare($sqlEvol);
            $stmt->execute([$weekStart->format('Y-m-d'), $weekEnd->format('Y-m-d')]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            $evol[] = [
                'label' => $weekStart->format('d/m'),
                'total' => (float)($data['total'] ?? 0),
                'normal' => (float)($data['normal'] ?? 0),
                'extra' => (float)($data['extra'] ?? 0),
                'noturna' => (float)($data['noturna'] ?? 0)
            ];
        }
    } else {
        // Agrupar por dia
        $current = clone $start;
        while ($current <= $end) {
            $sqlEvol = "
                SELECT
                    SUM(horas_normal) as normal,
                    SUM(horas_extra) as extra,
                    SUM(horas_noturna) as noturna,
                    SUM(horas_total) as total
                FROM apontamentos
                WHERE status = 'aprovado'
                AND semana_inicio = ?
                " . ($obraId ? " AND obra_id = $obraId" : "") . "
                " . ($employeeId ? " AND funcionario_id = $employeeId" : "");

            $stmt = $pdo->prepare($sqlEvol);
            $stmt->execute([$current->format('Y-m-d')]);
            $data = $stmt->fetch(PDO::FETCH_ASSOC);

            $evol[] = [
                'label' => $current->format('d/m'),
                'total' => (float)($data['total'] ?? 0),
                'normal' => (float)($data['normal'] ?? 0),
                'extra' => (float)($data['extra'] ?? 0),
                'noturna' => (float)($data['noturna'] ?? 0)
            ];

            $current->modify('+1 day');
        }
    }

    // ========================================
    // PERÍODO ANTERIOR (para comparação)
    // ========================================

    $comparison = null;

    if ($compareStartDate && $compareEndDate) {
        $compareParams = [$compareStartDate, $compareEndDate];
        if ($obraId) $compareParams[] = $obraId;
        if ($employeeId) $compareParams[] = $employeeId;

        $stmt = $pdo->prepare("
            SELECT
                SUM(a.horas_normal) as total_normal,
                SUM(a.horas_extra) as total_extra,
                SUM(a.horas_noturna) as total_noturna,
                SUM(a.horas_total) as total_horas,
                COUNT(DISTINCT a.funcionario_id) as total_funcionarios,
                COUNT(DISTINCT a.obra_id) as total_obras
            FROM apontamentos a
            WHERE $whereClause
        ");
        $stmt->execute($compareParams);
        $comparison = $stmt->fetch(PDO::FETCH_ASSOC);

        $comparison['custo_total'] =
            (($comparison['total_normal'] ?? 0) * $valores['valor_hora_normal']) +
            (($comparison['total_extra'] ?? 0) * $valores['valor_hora_extra']) +
            (($comparison['total_noturna'] ?? 0) * $valores['valor_hora_noturna']);
    }

    // ========================================
    // RESPOSTA
    // ========================================

    echo json_encode([
        'success' => true,
        'period' => [
            'start' => $startDate,
            'end' => $endDate,
            'days' => $diff + 1
        ],
        'totals' => [
            'horas_normal' => (float)($totais['total_normal'] ?? 0),
            'horas_extra' => (float)($totais['total_extra'] ?? 0),
            'horas_noturna' => (float)($totais['total_noturna'] ?? 0),
            'horas_total' => (float)($totais['total_horas'] ?? 0),
            'funcionarios' => (int)($totais['total_funcionarios'] ?? 0),
            'obras' => (int)($totais['total_obras'] ?? 0),
            'registros' => (int)($totais['total_registros'] ?? 0)
        ],
        'costs' => [
            'normal' => $custoNormal,
            'extra' => $custoExtra,
            'noturna' => $custoNoturna,
            'total' => $custoTotal
        ],
        'evolution' => $evol,
        'top_employees' => $funcionarios,
        'top_obras' => $obras,
        'comparison' => $comparison
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao processar analytics: ' . $e->getMessage()
    ]);
}
