<?php
/**
 * Export Analytics to Excel
 * Gera arquivo Excel (.xlsx) com dados completos de analytics
 */

header('Content-Type: application/json; charset=utf-8');
require_once '../../includes/auth.php';
require_once '../../config/database.php';

// Verificar autenticação
$user = authMiddleware(['admin', 'encarregado']);

try {
    // Parâmetros
    $startDate = $_GET['start_date'] ?? date('Y-m-01');
    $endDate = $_GET['end_date'] ?? date('Y-m-t');
    $obraId = isset($_GET['obra_id']) && $_GET['obra_id'] !== 'all' ? (int)$_GET['obra_id'] : null;
    $employeeId = isset($_GET['employee_id']) && $_GET['employee_id'] !== 'all' ? (int)$_GET['employee_id'] : null;

    // Buscar dados
    $params = [$startDate, $endDate];
    $obraFilter = $obraId ? " AND a.obra_id = ?" : "";
    $employeeFilter = $employeeId ? " AND a.funcionario_id = ?" : "";

    if ($obraId) $params[] = $obraId;
    if ($employeeId) $params[] = $employeeId;

    // Query detalhada de apontamentos
    $stmt = $pdo->prepare("
        SELECT
            a.data,
            u.nome as funcionario,
            u.passaporte,
            o.nome as obra,
            a.entrada_manha, a.saida_manha,
            a.entrada_tarde, a.saida_tarde,
            a.horas_normais, a.horas_extra, a.horas_noturna,
            (a.horas_normais + a.horas_extra + a.horas_noturna) as horas_total,
            a.status,
            a.observacoes
        FROM apontamentos a
        INNER JOIN usuarios u ON u.id = a.funcionario_id
        INNER JOIN obras o ON o.id = a.obra_id
        WHERE a.data BETWEEN ? AND ?
        AND a.status IN ('aprovado', 'pending')
        $obraFilter $employeeFilter
        ORDER BY a.data DESC, u.nome ASC
    ");
    $stmt->execute($params);
    $apontamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Estatísticas agregadas
    $statsStmt = $pdo->prepare("
        SELECT
            COUNT(DISTINCT a.funcionario_id) as total_funcionarios,
            COUNT(DISTINCT a.obra_id) as total_obras,
            SUM(a.horas_normais) as total_normal,
            SUM(a.horas_extra) as total_extra,
            SUM(a.horas_noturna) as total_noturna,
            SUM(a.horas_normais + a.horas_extra + a.horas_noturna) as total_horas,
            COUNT(*) as total_registros
        FROM apontamentos a
        WHERE a.data BETWEEN ? AND ?
        AND a.status IN ('aprovado', 'pending')
        $obraFilter $employeeFilter
    ");
    $statsStmt->execute($params);
    $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);

    // Criar CSV (Excel compatível com UTF-8 BOM)
    $filename = "analytics_" . date('Y-m-d_His') . ".csv";
    $filepath = __DIR__ . '/../../temp/' . $filename;

    // Criar diretório temp se não existir
    if (!is_dir(__DIR__ . '/../../temp')) {
        mkdir(__DIR__ . '/../../temp', 0755, true);
    }

    $file = fopen($filepath, 'w');

    // UTF-8 BOM para Excel reconhecer encoding
    fprintf($file, chr(0xEF).chr(0xBB).chr(0xBF));

    // Cabeçalho do relatório
    fputcsv($file, ['RELATÓRIO DE ANALYTICS - J2S ENGINYERIA'], ';');
    fputcsv($file, ['Período:', $startDate . ' até ' . $endDate], ';');
    fputcsv($file, ['Gerado em:', date('d/m/Y H:i:s')], ';');
    fputcsv($file, [''], ';');

    // Resumo executivo
    fputcsv($file, ['RESUMO EXECUTIVO'], ';');
    fputcsv($file, ['Total de Funcionários:', $stats['total_funcionarios']], ';');
    fputcsv($file, ['Total de Obras:', $stats['total_obras']], ';');
    fputcsv($file, ['Total de Registros:', $stats['total_registros']], ';');
    fputcsv($file, ['Horas Normais:', number_format($stats['total_normal'], 2, ',', '.') . 'h'], ';');
    fputcsv($file, ['Horas Extra:', number_format($stats['total_extra'], 2, ',', '.') . 'h'], ';');
    fputcsv($file, ['Horas Noturna:', number_format($stats['total_noturna'], 2, ',', '.') . 'h'], ';');
    fputcsv($file, ['TOTAL DE HORAS:', number_format($stats['total_horas'], 2, ',', '.') . 'h'], ';');
    fputcsv($file, [''], ';');
    fputcsv($file, [''], ';');

    // Dados detalhados
    fputcsv($file, ['DETALHAMENTO POR APONTAMENTO'], ';');
    fputcsv($file, [
        'Data',
        'Funcionário',
        'Passaporte',
        'Obra',
        'Entrada Manhã',
        'Saída Manhã',
        'Entrada Tarde',
        'Saída Tarde',
        'Horas Normais',
        'Horas Extra',
        'Horas Noturna',
        'Total Horas',
        'Status',
        'Observações'
    ], ';');

    foreach ($apontamentos as $apt) {
        fputcsv($file, [
            date('d/m/Y', strtotime($apt['data'])),
            $apt['funcionario'],
            $apt['passaporte'],
            $apt['obra'],
            $apt['entrada_manha'] ?: '-',
            $apt['saida_manha'] ?: '-',
            $apt['entrada_tarde'] ?: '-',
            $apt['saida_tarde'] ?: '-',
            number_format($apt['horas_normais'], 2, ',', '.'),
            number_format($apt['horas_extra'], 2, ',', '.'),
            number_format($apt['horas_noturna'], 2, ',', '.'),
            number_format($apt['horas_total'], 2, ',', '.'),
            $apt['status'] === 'aprovado' ? 'Aprovado' : 'Pendente',
            $apt['observacoes'] ?: '-'
        ], ';');
    }

    fclose($file);

    // Retornar URL do arquivo
    $fileUrl = str_replace($_SERVER['DOCUMENT_ROOT'], '', $filepath);
    $fileUrl = str_replace('\\', '/', $fileUrl);

    echo json_encode([
        'success' => true,
        'filename' => $filename,
        'url' => $fileUrl,
        'download_url' => '/backend/api/dashboard/download-export.php?file=' . urlencode($filename),
        'stats' => $stats
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao gerar exportação: ' . $e->getMessage()
    ]);
}
