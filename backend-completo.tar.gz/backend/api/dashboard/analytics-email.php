<?php
/**
 * Send Analytics Report by Email
 * Envia relatório de analytics por email com anexo
 */

header('Content-Type: application/json; charset=utf-8');
require_once '../../includes/auth.php';
require_once '../../includes/email.php';
require_once '../../config/database.php';

// Verificar autenticação
$user = authMiddleware(['admin', 'encarregado']);

try {
    // Receber dados
    $data = json_decode(file_get_contents('php://input'), true);

    $to = $data['email'] ?? '';
    $startDate = $data['start_date'] ?? date('Y-m-01');
    $endDate = $data['end_date'] ?? date('Y-m-t');
    $obraId = isset($data['obra_id']) && $data['obra_id'] !== 'all' ? (int)$data['obra_id'] : null;
    $employeeId = isset($data['employee_id']) && $data['employee_id'] !== 'all' ? (int)$data['employee_id'] : null;
    $includeAttachment = $data['include_attachment'] ?? true;

    // Validar email
    if (empty($to) || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Email inválido');
    }

    // Buscar estatísticas para o relatório
    $params = [$startDate, $endDate];
    $obraFilter = $obraId ? " AND a.obra_id = ?" : "";
    $employeeFilter = $employeeId ? " AND a.funcionario_id = ?" : "";

    if ($obraId) $params[] = $obraId;
    if ($employeeId) $params[] = $employeeId;

    // Estatísticas gerais
    $statsStmt = $pdo->prepare("
        SELECT
            COUNT(DISTINCT a.funcionario_id) as total_funcionarios,
            COUNT(DISTINCT a.obra_id) as total_obras,
            SUM(a.horas_normais) as total_normal,
            SUM(a.horas_extra) as total_extra,
            SUM(a.horas_noturna) as total_noturna,
            SUM(a.horas_normais + a.horas_extra + a.horas_noturna) as total_horas,
            COUNT(*) as total_registros
        FROM apontamentos a
        WHERE a.data BETWEEN ? AND ?
        AND a.status IN ('aprovado', 'pending')
        $obraFilter $employeeFilter
    ");
    $statsStmt->execute($params);
    $stats = $statsStmt->fetch(PDO::FETCH_ASSOC);

    // Top 5 funcionários
    $topStmt = $pdo->prepare("
        SELECT
            u.nome,
            SUM(a.horas_normais + a.horas_extra + a.horas_noturna) as horas_total
        FROM apontamentos a
        INNER JOIN usuarios u ON u.id = a.funcionario_id
        WHERE a.data BETWEEN ? AND ?
        AND a.status IN ('aprovado', 'pending')
        $obraFilter $employeeFilter
        GROUP BY a.funcionario_id
        ORDER BY horas_total DESC
        LIMIT 5
    ");
    $topStmt->execute($params);
    $topEmployees = $topStmt->fetchAll(PDO::FETCH_ASSOC);

    // Filtros aplicados
    $obraName = 'Todas';
    if ($obraId) {
        $obraStmt = $pdo->prepare("SELECT nome FROM obras WHERE id = ?");
        $obraStmt->execute([$obraId]);
        $obraName = $obraStmt->fetchColumn() ?: 'N/A';
    }

    $empName = 'Todos';
    if ($employeeId) {
        $empStmt = $pdo->prepare("SELECT nome FROM usuarios WHERE id = ?");
        $empStmt->execute([$employeeId]);
        $empName = $empStmt->fetchColumn() ?: 'N/A';
    }

    // Criar HTML do email
    $htmlBody = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #CE0201 0%, #a00101 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
            .header h1 { margin: 0; font-size: 28px; }
            .header p { margin: 10px 0 0 0; opacity: 0.9; }
            .content { background: #ffffff; padding: 30px; border: 1px solid #e5e7eb; }
            .stat-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
            .stat-box { background: #f9fafb; padding: 15px; border-radius: 6px; border-left: 4px solid #CE0201; }
            .stat-label { font-size: 13px; color: #6b7280; text-transform: uppercase; font-weight: 600; margin-bottom: 5px; }
            .stat-value { font-size: 24px; font-weight: bold; color: #111827; }
            .section { margin: 25px 0; }
            .section-title { font-size: 18px; font-weight: 600; color: #111827; margin-bottom: 15px; border-bottom: 2px solid #CE0201; padding-bottom: 8px; }
            .top-list { list-style: none; padding: 0; margin: 0; }
            .top-list li { padding: 10px; background: #f9fafb; margin-bottom: 8px; border-radius: 4px; display: flex; justify-content: space-between; }
            .footer { background: #f9fafb; padding: 20px; text-align: center; color: #6b7280; font-size: 13px; border-radius: 0 0 8px 8px; }
            .filter-info { background: #eff6ff; border: 1px solid #dbeafe; padding: 15px; border-radius: 6px; margin-bottom: 20px; }
            .filter-info strong { color: #1e40af; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>📊 Relatório de Analytics</h1>
                <p>J2S Enginyeria</p>
            </div>

            <div class='content'>
                <div class='filter-info'>
                    <strong>Período:</strong> " . date('d/m/Y', strtotime($startDate)) . " até " . date('d/m/Y', strtotime($endDate)) . "<br>
                    <strong>Obra:</strong> $obraName<br>
                    <strong>Empleado:</strong> $empName
                </div>

                <div class='section'>
                    <div class='section-title'>Resumo Executivo</div>
                    <div class='stat-grid'>
                        <div class='stat-box'>
                            <div class='stat-label'>Total de Horas</div>
                            <div class='stat-value'>" . number_format($stats['total_horas'], 2, ',', '.') . "h</div>
                        </div>
                        <div class='stat-box'>
                            <div class='stat-label'>Empleados</div>
                            <div class='stat-value'>" . $stats['total_funcionarios'] . "</div>
                        </div>
                        <div class='stat-box'>
                            <div class='stat-label'>Obras</div>
                            <div class='stat-value'>" . $stats['total_obras'] . "</div>
                        </div>
                        <div class='stat-box'>
                            <div class='stat-label'>Registros</div>
                            <div class='stat-value'>" . $stats['total_registros'] . "</div>
                        </div>
                    </div>
                </div>

                <div class='section'>
                    <div class='section-title'>Distribuição de Horas</div>
                    <ul class='top-list'>
                        <li>
                            <span><strong>Horas Normales</strong></span>
                            <span>" . number_format($stats['total_normal'], 2, ',', '.') . "h</span>
                        </li>
                        <li>
                            <span><strong>Horas Extra</strong></span>
                            <span>" . number_format($stats['total_extra'], 2, ',', '.') . "h</span>
                        </li>
                        <li>
                            <span><strong>Horas Nocturna</strong></span>
                            <span>" . number_format($stats['total_noturna'], 2, ',', '.') . "h</span>
                        </li>
                    </ul>
                </div>

                <div class='section'>
                    <div class='section-title'>Top 5 Empleados</div>
                    <ul class='top-list'>
    ";

    foreach ($topEmployees as $idx => $emp) {
        $htmlBody .= "
                        <li>
                            <span><strong>" . ($idx + 1) . ".</strong> " . htmlspecialchars($emp['nome']) . "</span>
                            <span>" . number_format($emp['horas_total'], 2, ',', '.') . "h</span>
                        </li>
        ";
    }

    $htmlBody .= "
                    </ul>
                </div>
            </div>

            <div class='footer'>
                <p>Relatório gerado automaticamente em " . date('d/m/Y H:i:s') . "</p>
                <p>J2S Enginyeria - Sistema de Gestión de Obras</p>
            </div>
        </div>
    </body>
    </html>
    ";

    // Plain text alternativo
    $plainBody = "
RELATÓRIO DE ANALYTICS - J2S ENGINYERIA

Período: " . date('d/m/Y', strtotime($startDate)) . " até " . date('d/m/Y', strtotime($endDate)) . "
Obra: $obraName
Empleado: $empName

RESUMO EXECUTIVO
- Total de Horas: " . number_format($stats['total_horas'], 2, ',', '.') . "h
- Empleados: " . $stats['total_funcionarios'] . "
- Obras: " . $stats['total_obras'] . "
- Registros: " . $stats['total_registros'] . "

DISTRIBUIÇÃO DE HORAS
- Horas Normales: " . number_format($stats['total_normal'], 2, ',', '.') . "h
- Horas Extra: " . number_format($stats['total_extra'], 2, ',', '.') . "h
- Horas Nocturna: " . number_format($stats['total_noturna'], 2, ',', '.') . "h

TOP 5 EMPLEADOS
";

    foreach ($topEmployees as $idx => $emp) {
        $plainBody .= ($idx + 1) . ". " . $emp['nome'] . " - " . number_format($emp['horas_total'], 2, ',', '.') . "h\n";
    }

    $plainBody .= "\nRelatório gerado em " . date('d/m/Y H:i:s') . "\nJ2S Enginyeria";

    // Enviar email
    $subject = "Relatório de Analytics - " . date('d/m/Y', strtotime($startDate)) . " a " . date('d/m/Y', strtotime($endDate));
    $emailSent = sendEmail($to, $subject, $htmlBody, $plainBody);

    if (!$emailSent) {
        throw new Exception('Falha ao enviar email. Verifique as configurações SMTP.');
    }

    echo json_encode([
        'success' => true,
        'message' => 'Relatório enviado com sucesso para ' . $to
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao enviar email: ' . $e->getMessage()
    ]);
}
