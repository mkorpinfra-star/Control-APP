<?php
/**
 * API: Criar Obra
 * POST /api/obras/create.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/jwt.php';

$headers = getallheaders();
$authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '');

if (empty($authHeader)) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$token = str_replace('Bearer ', '', $authHeader);
$payload = validateJWT($token);

if (!$payload || $payload['tipo'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data['numero']) || empty($data['nome'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Número e nome são obrigatórios']);
        exit;
    }

    $pdo = getConnection();

    // Verificar duplicidade
    $stmt = $pdo->prepare("SELECT id FROM obras WHERE numero = ?");
    $stmt->execute([$data['numero']]);
    if ($stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['error' => 'Número de obra já existe']);
        exit;
    }

    $sql = "INSERT INTO obras (numero, nome, endereco, email_financeiro, data_inicio, data_fim, cliente_id, encarregado_id, ativo, ativa)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 1)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        strtoupper($data['numero']),
        $data['nome'],
        isset($data['endereco']) ? $data['endereco'] : null,
        isset($data['email_financeiro']) ? $data['email_financeiro'] : null,
        isset($data['data_inicio']) ? $data['data_inicio'] : null,
        isset($data['data_fim']) ? $data['data_fim'] : null,
        isset($data['cliente_id']) ? $data['cliente_id'] : null,
        isset($data['encarregado_id']) ? $data['encarregado_id'] : null
    ]);

    $id = $pdo->lastInsertId();

    echo json_encode(['success' => true, 'id' => $id]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error', 'message' => $e->getMessage()]);
}
