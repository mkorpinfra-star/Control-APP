<?php
/**
 * API: Atualizar Obra
 * PUT /api/obras/update.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/jwt.php';

$headers = getallheaders();
$authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '');

if (empty($authHeader)) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$token = str_replace('Bearer ', '', $authHeader);
$payload = validateJWT($token);

if (!$payload || $payload['tipo'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data['id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'ID é obrigatório']);
        exit;
    }

    $pdo = getConnection();

    $updates = [];
    $params = [];

    if (!empty($data['numero'])) {
        $updates[] = "numero = ?";
        $params[] = strtoupper($data['numero']);
    }
    if (!empty($data['nome'])) {
        $updates[] = "nome = ?";
        $params[] = $data['nome'];
    }
    if (isset($data['endereco'])) {
        $updates[] = "endereco = ?";
        $params[] = $data['endereco'];
    }
    if (isset($data['email_financeiro'])) {
        $updates[] = "email_financeiro = ?";
        $params[] = $data['email_financeiro'];
    }
    if (isset($data['cliente_id'])) {
        $updates[] = "cliente_id = ?";
        $params[] = $data['cliente_id'] ? $data['cliente_id'] : null;
    }
    if (isset($data['encarregado_id'])) {
        $updates[] = "encarregado_id = ?";
        $params[] = $data['encarregado_id'] ? $data['encarregado_id'] : null;
    }
    if (isset($data['data_inicio'])) {
        $updates[] = "data_inicio = ?";
        $params[] = $data['data_inicio'] ? $data['data_inicio'] : null;
    }
    if (isset($data['data_fim'])) {
        $updates[] = "data_fim = ?";
        $params[] = $data['data_fim'] ? $data['data_fim'] : null;
    }

    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(['error' => 'Nenhum campo para atualizar']);
        exit;
    }

    $sql = "UPDATE obras SET " . implode(', ', $updates) . " WHERE id = ?";
    $params[] = $data['id'];

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode(['success' => true]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error', 'message' => $e->getMessage()]);
}
