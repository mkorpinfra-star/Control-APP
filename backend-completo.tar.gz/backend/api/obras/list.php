<?php
/**
 * API: Listar Obras
 * GET /api/obras/list.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/jwt.php';

$headers = getallheaders();
$authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '');

if (empty($authHeader)) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$token = str_replace('Bearer ', '', $authHeader);
$payload = validateJWT($token);

if (!$payload) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid token']);
    exit;
}

try {
    $pdo = getConnection();

    $sql = "
        SELECT o.id, o.numero, o.nome, o.endereco, o.email_financeiro, o.cliente_id, o.encarregado_id,
               c.nome as cliente_nome,
               u.nome as encarregado_nome,
               (SELECT COUNT(*) FROM funcionario_obra WHERE obra_id = o.id) as funcionarios_count
        FROM obras o
        LEFT JOIN clientes c ON o.cliente_id = c.id
        LEFT JOIN usuarios u ON o.encarregado_id = u.id
        WHERE o.ativo = 1
        ORDER BY o.numero DESC
    ";

    $stmt = $pdo->query($sql);
    $obras = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($obras);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error', 'message' => $e->getMessage()]);
}
