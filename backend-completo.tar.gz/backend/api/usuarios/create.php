<?php
/**
 * API: Criar Usuário
 * POST /api/usuarios/create.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/jwt.php';

$headers = getallheaders();
$authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '');

if (empty($authHeader)) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$token = str_replace('Bearer ', '', $authHeader);
$payload = validateJWT($token);

if (!$payload || $payload['tipo'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden - Only admin']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data['passaporte']) || empty($data['nome']) || empty($data['senha'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Passaporte, nome e senha são obrigatórios']);
        exit;
    }

    $pdo = getConnection();

    // Verificar se passaporte já existe
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE passaporte = ?");
    $stmt->execute([strtoupper($data['passaporte'])]);
    if ($stmt->fetch()) {
        http_response_code(400);
        echo json_encode(['error' => 'Passaporte já cadastrado']);
        exit;
    }

    $senhaHash = password_hash($data['senha'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO usuarios (passaporte, senha_hash, nome, email, telefone, funcao, tipo, ativo, salario_base, salario_hora, vale_moradia, ibf)
            VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        strtoupper($data['passaporte']),
        $senhaHash,
        $data['nome'],
        isset($data['email']) ? $data['email'] : null,
        isset($data['telefone']) ? $data['telefone'] : null,
        isset($data['funcao']) ? $data['funcao'] : null,
        isset($data['tipo']) ? $data['tipo'] : 'funcionario',
        isset($data['salario_base']) ? $data['salario_base'] : null,
        isset($data['salario_hora']) ? $data['salario_hora'] : null,
        isset($data['vale_moradia']) ? $data['vale_moradia'] : null,
        isset($data['ibf']) ? $data['ibf'] : null
    ]);

    $id = $pdo->lastInsertId();

    echo json_encode(['success' => true, 'id' => $id]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error', 'message' => $e->getMessage()]);
}
