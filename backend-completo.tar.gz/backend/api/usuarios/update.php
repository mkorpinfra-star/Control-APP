<?php
/**
 * API: Atualizar Usuário
 * PUT /api/usuarios/update.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: PUT, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/jwt.php';

$headers = getallheaders();
$authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '');

if (empty($authHeader)) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$token = str_replace('Bearer ', '', $authHeader);
$payload = validateJWT($token);

if (!$payload || $payload['tipo'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Forbidden - Only admin']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data['id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'ID é obrigatório']);
        exit;
    }

    $pdo = getConnection();

    $updates = [];
    $params = [];

    if (!empty($data['nome'])) {
        $updates[] = "nome = ?";
        $params[] = $data['nome'];
    }
    if (!empty($data['passaporte'])) {
        $updates[] = "passaporte = ?";
        $params[] = strtoupper($data['passaporte']);
    }
    if (isset($data['email'])) {
        $updates[] = "email = ?";
        $params[] = $data['email'];
    }
    if (isset($data['telefone'])) {
        $updates[] = "telefone = ?";
        $params[] = $data['telefone'];
    }
    if (isset($data['funcao'])) {
        $updates[] = "funcao = ?";
        $params[] = $data['funcao'];
    }
    if (!empty($data['tipo'])) {
        $updates[] = "tipo = ?";
        $params[] = $data['tipo'];
    }
    if (!empty($data['senha'])) {
        $updates[] = "senha_hash = ?";
        $params[] = password_hash($data['senha'], PASSWORD_DEFAULT);
    }
    if (isset($data['salario_base'])) {
        $updates[] = "salario_base = ?";
        $params[] = $data['salario_base'];
    }
    if (isset($data['salario_hora'])) {
        $updates[] = "salario_hora = ?";
        $params[] = $data['salario_hora'];
    }
    if (isset($data['vale_moradia'])) {
        $updates[] = "vale_moradia = ?";
        $params[] = $data['vale_moradia'];
    }
    if (isset($data['ibf'])) {
        $updates[] = "ibf = ?";
        $params[] = $data['ibf'];
    }

    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(['error' => 'Nenhum campo para atualizar']);
        exit;
    }

    $sql = "UPDATE usuarios SET " . implode(', ', $updates) . " WHERE id = ?";
    $params[] = $data['id'];

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode(['success' => true]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error', 'message' => $e->getMessage()]);
}
