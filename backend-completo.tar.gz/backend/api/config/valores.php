<?php
/**
 * API: Buscar configuração de valores de hora
 * GET /api/config/valores.php
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../includes/jwt.php';

$headers = getallheaders();
$authHeader = isset($headers['Authorization']) ? $headers['Authorization'] : (isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '');

if (empty($authHeader)) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$token = str_replace('Bearer ', '', $authHeader);
$user = validateJWT($token);

if (!$user) {
    http_response_code(401);
    echo json_encode(['error' => 'Invalid token']);
    exit;
}

try {
    $pdo = getConnection();

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        // Buscar configuração atual
        $stmt = $pdo->query("SELECT * FROM config_valores ORDER BY id DESC LIMIT 1");
        $config = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$config) {
            // Valores padrão
            $config = [
                'valor_hora_normal' => 21.00,
                'valor_hora_extra' => 28.00,
                'valor_hora_noturna' => 30.00
            ];
        }

        echo json_encode($config);
    } else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Apenas admin pode alterar
        if ($user['tipo'] !== 'admin') {
            http_response_code(403);
            echo json_encode(['error' => 'Forbidden']);
            exit;
        }

        $input = json_decode(file_get_contents('php://input'), true);

        $valor_normal = isset($input['valor_hora_normal']) ? floatval($input['valor_hora_normal']) : 21.00;
        $valor_extra = isset($input['valor_hora_extra']) ? floatval($input['valor_hora_extra']) : 28.00;
        $valor_noturna = isset($input['valor_hora_noturna']) ? floatval($input['valor_hora_noturna']) : 30.00;

        // Verificar se já existe registro
        $stmt = $pdo->query("SELECT id FROM config_valores ORDER BY id DESC LIMIT 1");
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existing) {
            $stmt = $pdo->prepare("UPDATE config_valores SET valor_hora_normal = ?, valor_hora_extra = ?, valor_hora_noturna = ?, atualizado_em = NOW() WHERE id = ?");
            $stmt->execute([$valor_normal, $valor_extra, $valor_noturna, $existing['id']]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO config_valores (valor_hora_normal, valor_hora_extra, valor_hora_noturna) VALUES (?, ?, ?)");
            $stmt->execute([$valor_normal, $valor_extra, $valor_noturna]);
        }

        echo json_encode([
            'success' => true,
            'message' => 'Valores actualizados',
            'valores' => [
                'valor_hora_normal' => $valor_normal,
                'valor_hora_extra' => $valor_extra,
                'valor_hora_noturna' => $valor_noturna
            ]
        ]);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error', 'message' => $e->getMessage()]);
}
