<?php
/**
 * GERAR FOLHA DE PAGAMENTO MENSAL
 * Calcula automaticamente com base nos apontamentos aprovados
 */

header('Content-Type: application/json; charset=utf-8');
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$user = authMiddleware(['admin']);

try {
    $mesReferencia = $_GET['mes'] ?? date('Y-m');
    $obraId = isset($_GET['obra_id']) && $_GET['obra_id'] !== 'all' ? (int)$_GET['obra_id'] : null;

    $pdo = getConnection();

    // Buscar config fiscal
    $configStmt = $pdo->query("SELECT * FROM config_fiscal ORDER BY id DESC LIMIT 1");
    $config = $configStmt->fetch(PDO::FETCH_ASSOC);

    $casDescFuncionario = $config['cas_desconto_funcionario'] ?? 6.50;
    $casCustoEmpresa = $config['cas_custo_empresa'] ?? 15.50;

    // Buscar todos apontamentos aprovados do mês
    $mesInicio = $mesReferencia . '-01';
    $mesFim = date('Y-m-t', strtotime($mesInicio));

    $whereObra = $obraId ? " AND a.obra_id = :obra_id" : "";
    $params = ['mes_inicio' => $mesInicio, 'mes_fim' => $mesFim];
    if ($obraId) $params['obra_id'] = $obraId;

    $stmt = $pdo->prepare("
        SELECT
            a.funcionario_id,
            a.obra_id,
            u.funcao,
            u.salario_base,
            u.salario_hora,
            u.vale_moradia,
            u.ibf,
            SUM(a.horas_normais) as total_horas_normais,
            SUM(a.horas_extra) as total_horas_extra,
            SUM(a.horas_noturna) as total_horas_noturna
        FROM apontamentos a
        INNER JOIN usuarios u ON u.id = a.funcionario_id
        WHERE a.status = 'aprovado'
        AND a.semana_inicio >= :mes_inicio
        AND a.semana_inicio <= :mes_fim
        $whereObra
        GROUP BY a.funcionario_id, a.obra_id
    ");
    $stmt->execute($params);
    $apontamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $gerados = 0;
    $atualizados = 0;

    foreach ($apontamentos as $apt) {
        // Verificar se já existe
        $checkStmt = $pdo->prepare("
            SELECT id FROM folha_pagamento
            WHERE funcionario_id = ? AND obra_id = ? AND mes_referencia = ?
        ");
        $checkStmt->execute([$apt['funcionario_id'], $apt['obra_id'], $mesReferencia]);
        $existing = $checkStmt->fetch();

        if ($existing) {
            // Atualizar
            $updateStmt = $pdo->prepare("
                UPDATE folha_pagamento SET
                    horas_normais = :horas_normais,
                    horas_extra = :horas_extra,
                    horas_noturna = :horas_noturna,
                    salario_base = :salario_base,
                    salario_hora = :salario_hora,
                    vale_moradia = :vale_moradia,
                    ibf = :ibf,
                    cas_desconto_funcionario_percentual = :cas_desc,
                    cas_custo_empresa_percentual = :cas_custo
                WHERE id = :id
            ");
            $updateStmt->execute([
                'horas_normais' => $apt['total_horas_normais'],
                'horas_extra' => $apt['total_horas_extra'],
                'horas_noturna' => $apt['total_horas_noturna'],
                'salario_base' => $apt['salario_base'],
                'salario_hora' => $apt['salario_hora'],
                'vale_moradia' => $apt['vale_moradia'],
                'ibf' => $apt['ibf'],
                'cas_desc' => $casDescFuncionario,
                'cas_custo' => $casCustoEmpresa,
                'id' => $existing['id']
            ]);
            $atualizados++;
        } else {
            // Criar novo
            $insertStmt = $pdo->prepare("
                INSERT INTO folha_pagamento (
                    funcionario_id, obra_id, mes_referencia,
                    horas_normais, horas_extra, horas_noturna,
                    salario_base, salario_hora, vale_moradia, ibf,
                    cas_desconto_funcionario_percentual, cas_custo_empresa_percentual
                ) VALUES (
                    :funcionario_id, :obra_id, :mes_referencia,
                    :horas_normais, :horas_extra, :horas_noturna,
                    :salario_base, :salario_hora, :vale_moradia, :ibf,
                    :cas_desc, :cas_custo
                )
            ");
            $insertStmt->execute([
                'funcionario_id' => $apt['funcionario_id'],
                'obra_id' => $apt['obra_id'],
                'mes_referencia' => $mesReferencia,
                'horas_normais' => $apt['total_horas_normais'],
                'horas_extra' => $apt['total_horas_extra'],
                'horas_noturna' => $apt['total_horas_noturna'],
                'salario_base' => $apt['salario_base'],
                'salario_hora' => $apt['salario_hora'],
                'vale_moradia' => $apt['vale_moradia'],
                'ibf' => $apt['ibf'],
                'cas_desc' => $casDescFuncionario,
                'cas_custo' => $casCustoEmpresa
            ]);
            $gerados++;
        }
    }

    echo json_encode([
        'success' => true,
        'mes_referencia' => $mesReferencia,
        'gerados' => $gerados,
        'atualizados' => $atualizados,
        'total' => $gerados + $atualizados
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao gerar folha: ' . $e->getMessage()
    ]);
}
