<?php
/**
 * GERAR FATURAMENTO MENSAL
 * Calcula automaticamente com base nos apontamentos aprovados
 * Valores de faturamento são DIFERENTES dos valores de folha (markup)
 */

header('Content-Type: application/json; charset=utf-8');
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$user = authMiddleware(['admin']);

try {
    $mesReferencia = $_GET['mes'] ?? date('Y-m');
    $obraId = isset($_GET['obra_id']) && $_GET['obra_id'] !== 'all' ? (int)$_GET['obra_id'] : null;

    $pdo = getConnection();

    // Buscar config fiscal
    $configStmt = $pdo->query("SELECT * FROM config_fiscal ORDER BY id DESC LIMIT 1");
    $config = $configStmt->fetch(PDO::FETCH_ASSOC);

    $igiPercentual = $config['igi_percentual'] ?? 4.50;

    // Buscar valores de faturamento (cobrados do cliente)
    $valoresStmt = $pdo->query("SELECT * FROM config_valores_faturamento ORDER BY id DESC LIMIT 1");
    $valoresFat = $valoresStmt->fetch(PDO::FETCH_ASSOC);

    if (!$valoresFat) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'message' => 'Configure os valores de faturamento antes de gerar faturas'
        ]);
        exit;
    }

    $valorHoraNormalFat = floatval($valoresFat['valor_hora_normal_faturamento']);
    $valorHoraExtraFat = floatval($valoresFat['valor_hora_extra_faturamento']);
    $valorHoraNoturnaFat = floatval($valoresFat['valor_hora_noturna_faturamento']);

    // Buscar todos apontamentos aprovados do mês
    $mesInicio = $mesReferencia . '-01';
    $mesFim = date('Y-m-t', strtotime($mesInicio));

    $whereObra = $obraId ? " AND a.obra_id = :obra_id" : "";
    $params = ['mes_inicio' => $mesInicio, 'mes_fim' => $mesFim];
    if ($obraId) $params['obra_id'] = $obraId;

    $stmt = $pdo->prepare("
        SELECT
            a.obra_id,
            o.numero as obra_numero,
            o.nome as obra_nome,
            SUM(a.horas_normais) as total_horas_normais,
            SUM(a.horas_extra) as total_horas_extra,
            SUM(a.horas_noturna) as total_horas_noturna
        FROM apontamentos a
        INNER JOIN obras o ON o.id = a.obra_id
        WHERE a.status = 'aprovado'
        AND a.semana_inicio >= :mes_inicio
        AND a.semana_inicio <= :mes_fim
        $whereObra
        GROUP BY a.obra_id
    ");
    $stmt->execute($params);
    $apontamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $gerados = 0;
    $atualizados = 0;

    foreach ($apontamentos as $apt) {
        // Verificar se já existe
        $checkStmt = $pdo->prepare("
            SELECT id FROM faturamento
            WHERE obra_id = ? AND mes_referencia = ?
        ");
        $checkStmt->execute([$apt['obra_id'], $mesReferencia]);
        $existing = $checkStmt->fetch();

        // Calcular valores manualmente
        $valorHorasNormais = $apt['total_horas_normais'] * $valorHoraNormalFat;
        $valorHorasExtra = $apt['total_horas_extra'] * $valorHoraExtraFat;
        $valorHorasNoturna = $apt['total_horas_noturna'] * $valorHoraNoturnaFat;
        $valorTotalServicos = $valorHorasNormais + $valorHorasExtra + $valorHorasNoturna;

        if ($existing) {
            // Atualizar
            $updateStmt = $pdo->prepare("
                UPDATE faturamento SET
                    horas_normais = :horas_normais,
                    horas_extra = :horas_extra,
                    horas_noturna = :horas_noturna,
                    valor_hora_normal = :valor_hora_normal,
                    valor_hora_extra = :valor_hora_extra,
                    valor_hora_noturna = :valor_hora_noturna,
                    valor_total_servicos = :valor_total_servicos,
                    igi_percentual = :igi_percentual
                WHERE id = :id
            ");
            $updateStmt->execute([
                'horas_normais' => $apt['total_horas_normais'],
                'horas_extra' => $apt['total_horas_extra'],
                'horas_noturna' => $apt['total_horas_noturna'],
                'valor_hora_normal' => $valorHoraNormalFat,
                'valor_hora_extra' => $valorHoraExtraFat,
                'valor_hora_noturna' => $valorHoraNoturnaFat,
                'valor_total_servicos' => $valorTotalServicos,
                'igi_percentual' => $igiPercentual,
                'id' => $existing['id']
            ]);
            $atualizados++;
        } else {
            // Criar novo
            $insertStmt = $pdo->prepare("
                INSERT INTO faturamento (
                    obra_id, mes_referencia,
                    horas_normais, horas_extra, horas_noturna,
                    valor_hora_normal, valor_hora_extra, valor_hora_noturna,
                    valor_total_servicos, igi_percentual
                ) VALUES (
                    :obra_id, :mes_referencia,
                    :horas_normais, :horas_extra, :horas_noturna,
                    :valor_hora_normal, :valor_hora_extra, :valor_hora_noturna,
                    :valor_total_servicos, :igi_percentual
                )
            ");
            $insertStmt->execute([
                'obra_id' => $apt['obra_id'],
                'mes_referencia' => $mesReferencia,
                'horas_normais' => $apt['total_horas_normais'],
                'horas_extra' => $apt['total_horas_extra'],
                'horas_noturna' => $apt['total_horas_noturna'],
                'valor_hora_normal' => $valorHoraNormalFat,
                'valor_hora_extra' => $valorHoraExtraFat,
                'valor_hora_noturna' => $valorHoraNoturnaFat,
                'valor_total_servicos' => $valorTotalServicos,
                'igi_percentual' => $igiPercentual
            ]);
            $gerados++;
        }
    }

    echo json_encode([
        'success' => true,
        'mes_referencia' => $mesReferencia,
        'gerados' => $gerados,
        'atualizados' => $atualizados,
        'total' => $gerados + $atualizados
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao gerar faturamento: ' . $e->getMessage()
    ]);
}
