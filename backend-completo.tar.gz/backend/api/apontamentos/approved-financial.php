<?php
/**
 * APONTAMENTOS APROVADOS COM VALORES FINANCEIROS
 * Para Admin visualizar valores após aprovação do encarregado
 */

header('Content-Type: application/json; charset=utf-8');
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$user = authMiddleware(['admin']);

try {
    $inicio = $_GET['inicio'] ?? null;
    $fim = $_GET['fim'] ?? null;
    $obraId = isset($_GET['obra_id']) ? (int)$_GET['obra_id'] : null;

    if (!$inicio || !$fim) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Parâmetros inicio e fim obrigatórios']);
        exit;
    }

    $pdo = getConnection();

    $whereObra = $obraId ? " AND a.obra_id = :obra_id" : "";
    $params = ['inicio' => $inicio, 'fim' => $fim];
    if ($obraId) $params['obra_id'] = $obraId;

    $stmt = $pdo->prepare("
        SELECT
            a.id,
            a.funcionario_id,
            a.obra_id,
            a.semana_inicio,
            a.semana_fim,
            a.total_horas,
            a.horas_normais,
            a.horas_extra,
            a.horas_noturna,
            a.status,
            a.data_aprovacao,
            a.aprovado_por,

            u.nome as funcionario_nome,
            u.passaporte as funcionario_passaporte,
            u.funcao as funcionario_funcao,

            o.numero as obra_numero,
            o.nome as obra_nome,

            aprovador.nome as aprovador_nome

        FROM apontamentos a
        INNER JOIN usuarios u ON u.id = a.funcionario_id
        INNER JOIN obras o ON o.id = a.obra_id
        LEFT JOIN usuarios aprovador ON aprovador.id = a.aprovado_por

        WHERE a.status = 'aprovado'
        AND a.semana_inicio >= :inicio
        AND a.semana_fim <= :fim
        $whereObra

        ORDER BY a.semana_inicio DESC, o.numero, u.nome
    ");

    $stmt->execute($params);
    $apontamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'success' => true,
        'apontamentos' => $apontamentos
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao buscar apontamentos: ' . $e->getMessage()
    ]);
}
