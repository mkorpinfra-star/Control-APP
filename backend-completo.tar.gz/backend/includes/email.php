<?php
/**
 * Serviço de Envio de E-mails via SMTP
 * Sistema de Marcação de Ponto
 * 
 * Usando PHPMailer-like socket connection para SSL/TLS
 */

require_once __DIR__ . '/../config/database.php';

/**
 * Envia e-mail usando SMTP com SSL
 */
function sendEmail($to, $subject, $htmlBody, $plainBody = null)
{
    // Obter configurações SMTP do banco
    $smtpHost = getConfig('smtp_host');
    $smtpPort = getConfig('smtp_port') ?: 465;
    $smtpUser = getConfig('smtp_user');
    $smtpPass = getConfig('smtp_password');
    $smtpFrom = getConfig('smtp_from') ?: $smtpUser;

    if (empty($smtpHost) || empty($smtpUser) || empty($smtpPass)) {
        error_log("[SMTP] Configuração incompleta. E-mail não enviado para: $to");
        return false;
    }

    try {
        // Conectar ao servidor SMTP com SSL
        $context = stream_context_create([
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ]);

        $socket = stream_socket_client(
            "ssl://{$smtpHost}:{$smtpPort}",
            $errno,
            $errstr,
            30,
            STREAM_CLIENT_CONNECT,
            $context
        );

        if (!$socket) {
            error_log("[SMTP] Falha ao conectar: $errstr ($errno)");
            return false;
        }

        // Ler resposta inicial
        $response = fgets($socket, 512);
        if (substr($response, 0, 3) != '220') {
            error_log("[SMTP] Resposta inesperada: $response");
            fclose($socket);
            return false;
        }

        // EHLO
        fputs($socket, "EHLO j2s.ad\r\n");
        while ($line = fgets($socket, 512)) {
            if (substr($line, 3, 1) == ' ')
                break;
        }

        // AUTH LOGIN
        fputs($socket, "AUTH LOGIN\r\n");
        fgets($socket, 512);

        fputs($socket, base64_encode($smtpUser) . "\r\n");
        fgets($socket, 512);

        fputs($socket, base64_encode($smtpPass) . "\r\n");
        $authResponse = fgets($socket, 512);
        if (substr($authResponse, 0, 3) != '235') {
            error_log("[SMTP] Autenticação falhou: $authResponse");
            fclose($socket);
            return false;
        }

        // MAIL FROM
        fputs($socket, "MAIL FROM:<{$smtpFrom}>\r\n");
        fgets($socket, 512);

        // RCPT TO
        fputs($socket, "RCPT TO:<{$to}>\r\n");
        fgets($socket, 512);

        // DATA
        fputs($socket, "DATA\r\n");
        fgets($socket, 512);

        // Headers
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: Sistema de Control Horario <{$smtpFrom}>\r\n";
        $headers .= "To: {$to}\r\n";
        $headers .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
        $headers .= "Date: " . date('r') . "\r\n";
        $headers .= "\r\n";

        // Enviar headers + corpo
        fputs($socket, $headers);
        fputs($socket, $htmlBody);
        fputs($socket, "\r\n.\r\n");

        $dataResponse = fgets($socket, 512);
        if (substr($dataResponse, 0, 3) != '250') {
            error_log("[SMTP] Erro ao enviar dados: $dataResponse");
            fclose($socket);
            return false;
        }

        // QUIT
        fputs($socket, "QUIT\r\n");
        fclose($socket);

        error_log("[SMTP] E-mail enviado com sucesso para: $to");
        return true;

    } catch (Exception $e) {
        error_log("[SMTP] Exceção: " . $e->getMessage());
        return false;
    }
}

/**
 * Template de e-mail para notificação ao encarregado
 */
function sendApprovalNotification($encarregadoEmail, $funcionarioNome, $obraNumero, $semana, $totalHoras)
{
    $subject = "Nuevo registro de horas pendiente de aprobación";

    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: 'Inter', Arial, sans-serif; line-height: 1.6; color: #1f2937; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2563eb; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9fafb; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px; }
            .info-box { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 15px; margin: 15px 0; }
            .label { font-size: 12px; color: #6b7280; text-transform: uppercase; }
            .value { font-size: 16px; font-weight: 600; color: #1f2937; }
            .btn { display: inline-block; background: #2563eb; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 20px; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #6b7280; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1 style='margin:0;'>Sistema de Control Horario</h1>
            </div>
            <div class='content'>
                <h2>Nuevo registro pendiente de aprobación</h2>
                <p>Se ha recibido un nuevo registro de horas que requiere su aprobación.</p>
                
                <div class='info-box'>
                    <div class='label'>Empleado</div>
                    <div class='value'>$funcionarioNome</div>
                </div>
                
                <div class='info-box'>
                    <div class='label'>Obra</div>
                    <div class='value'>$obraNumero</div>
                </div>
                
                <div class='info-box'>
                    <div class='label'>Semana</div>
                    <div class='value'>$semana</div>
                </div>
                
                <div class='info-box'>
                    <div class='label'>Total de horas</div>
                    <div class='value'>{$totalHoras}h</div>
                </div>
                
                <p>Por favor, acceda al sistema para revisar y aprobar este registro.</p>
            </div>
            <div class='footer'>
                <p>Este es un mensaje automático del Sistema de Control Horario.</p>
            </div>
        </div>
    </body>
    </html>
    ";

    return sendEmail($encarregadoEmail, $subject, $html);
}

/**
 * Template de e-mail para envio ao financeiro após aprovação
 * NOTA: Email semanal SEM valores (só conferência)
 * Na última semana do mês, envia também o relatório consolidado COM valores
 */
function sendToFinance($apontamento, $assinatura, $emailDestino = null)
{
    $financeEmail = $emailDestino ?: getConfig('email_financeiro') ?: 'contactes@j2s.ad';
    $pdo = getConnection();

    // Verificar se é a última semana do mês
    $semanaInicio = new DateTime($apontamento['semana_inicio']);
    $proximaSemana = clone $semanaInicio;
    $proximaSemana->modify('+7 days');

    $mesAtual = $semanaInicio->format('Y-m');
    $mesProximaSemana = $proximaSemana->format('Y-m');

    // É última semana se o próximo início de semana cair no mês seguinte
    $isUltimaSemana = ($mesAtual !== $mesProximaSemana);

    // ========================================
    // 1. ENVIAR EMAIL SEMANAL COM VALORES FINANCEIROS COMPLETOS
    // ========================================

    // BUSCAR VALORES CONFIGURADOS DE HORA
    $stmt = $pdo->query("SELECT * FROM config_valores ORDER BY id DESC LIMIT 1");
    $config = $stmt->fetch(PDO::FETCH_ASSOC);

    $valorNormal = isset($config['valor_hora_normal']) ? floatval($config['valor_hora_normal']) : 21.00;
    $valorExtra = isset($config['valor_hora_extra']) ? floatval($config['valor_hora_extra']) : 28.00;
    $valorNoturna = isset($config['valor_hora_noturna']) ? floatval($config['valor_hora_noturna']) : 30.00;

    $subject = "💰 Registro aprobado - {$apontamento['funcionario_nome']} - Semana {$apontamento['semana_inicio']}";

    $horasJson = json_decode($apontamento['horas_diarias'], true);
    $dias = ['mon' => 'Lunes', 'tue' => 'Martes', 'wed' => 'Miércoles', 'thu' => 'Jueves', 'fri' => 'Viernes', 'sat' => 'Sábado'];

    // Verificar se é formato novo
    $isNewFormat = false;
    if ($horasJson && is_array($horasJson)) {
        $firstValue = reset($horasJson);
        $isNewFormat = is_array($firstValue);
    }

    $totalNormal = 0;
    $totalExtra = 0;
    $totalNoturna = 0;

    if ($isNewFormat) {
        // Formato novo com 3 categorias - COM VALORES FINANCEIROS
        $horasHtml = "<tr style='background:#f8f9fa;'>
            <th style='padding:10px 8px;text-align:left;font-weight:600;border-bottom:2px solid #e5e7eb;'>Día</th>
            <th style='padding:10px 8px;text-align:center;font-weight:600;border-bottom:2px solid #e5e7eb;background:#dcfce7;color:#166534;'>Normal<br><span style='font-size:10px;font-weight:400;'>€" . number_format($valorNormal, 2) . "/h</span></th>
            <th style='padding:10px 8px;text-align:center;font-weight:600;border-bottom:2px solid #e5e7eb;background:#fef3c7;color:#92400e;'>Extra<br><span style='font-size:10px;font-weight:400;'>€" . number_format($valorExtra, 2) . "/h</span></th>
            <th style='padding:10px 8px;text-align:center;font-weight:600;border-bottom:2px solid #e5e7eb;background:#e0e7ff;color:#3730a3;'>Nocturna<br><span style='font-size:10px;font-weight:400;'>€" . number_format($valorNoturna, 2) . "/h</span></th>
            <th style='padding:10px 8px;text-align:right;font-weight:600;border-bottom:2px solid #e5e7eb;'>Valor día</th>
        </tr>";

        foreach ($dias as $key => $nome) {
            $dayData = isset($horasJson[$key]) ? $horasJson[$key] : array('normal' => 0, 'extra' => 0, 'noturna' => 0, 'fecha' => '');
            $normal = isset($dayData['normal']) ? floatval($dayData['normal']) : 0;
            $extra = isset($dayData['extra']) ? floatval($dayData['extra']) : 0;
            $noturna = isset($dayData['noturna']) ? floatval($dayData['noturna']) : 0;
            $fecha = isset($dayData['fecha']) ? $dayData['fecha'] : '';

            $totalNormal += $normal;
            $totalExtra += $extra;
            $totalNoturna += $noturna;

            // CALCULAR VALOR DO DIA
            $valorDia = ($normal * $valorNormal) + ($extra * $valorExtra) + ($noturna * $valorNoturna);

            $fechaDisplay = '';
            if ($fecha) {
                $dateObj = new DateTime($fecha);
                $fechaDisplay = " <span style='font-size:11px;color:#666;'>(" . $dateObj->format('d/m') . ")</span>";
            }

            $horasHtml .= "<tr style='border-bottom:1px solid #e5e7eb;'>
                <td style='padding:8px;font-weight:500;'>{$nome}{$fechaDisplay}</td>
                <td style='padding:8px;text-align:center;color:#166534;'>{$normal}h</td>
                <td style='padding:8px;text-align:center;color:#92400e;'>{$extra}h</td>
                <td style='padding:8px;text-align:center;color:#3730a3;'>{$noturna}h</td>
                <td style='padding:8px;text-align:right;font-weight:600;color:#16a34a;'>€" . number_format($valorDia, 2) . "</td>
            </tr>";
        }

        $totalGeral = $totalNormal + $totalExtra + $totalNoturna;

        // CALCULAR VALORES TOTAIS
        $valorTotalNormal = $totalNormal * $valorNormal;
        $valorTotalExtra = $totalExtra * $valorExtra;
        $valorTotalNoturna = $totalNoturna * $valorNoturna;
        $valorTotalSemana = $valorTotalNormal + $valorTotalExtra + $valorTotalNoturna;

        $horasHtml .= "<tr style='background:#f8f9fa;font-weight:600;'>
            <td style='padding:10px 8px;'>TOTAL</td>
            <td style='padding:10px 8px;text-align:center;color:#166534;'>{$totalNormal}h</td>
            <td style='padding:10px 8px;text-align:center;color:#92400e;'>{$totalExtra}h</td>
            <td style='padding:10px 8px;text-align:center;color:#3730a3;'>{$totalNoturna}h</td>
            <td style='padding:10px 8px;text-align:right;font-size:16px;color:#16a34a;'>€" . number_format($valorTotalSemana, 2) . "</td>
        </tr>";

        $resumoHtml = "<div style='display:flex;gap:10px;margin-bottom:15px;flex-wrap:wrap;'>
            <span style='padding:6px 12px;border-radius:6px;font-size:13px;background:#dcfce7;color:#166534;font-weight:600;'>Normal: {$totalNormal}h</span>";
        if ($totalExtra > 0) {
            $resumoHtml .= "<span style='padding:6px 12px;border-radius:6px;font-size:13px;background:#fef3c7;color:#92400e;font-weight:600;'>Extra: {$totalExtra}h</span>";
        }
        if ($totalNoturna > 0) {
            $resumoHtml .= "<span style='padding:6px 12px;border-radius:6px;font-size:13px;background:#e0e7ff;color:#3730a3;font-weight:600;'>Nocturna: {$totalNoturna}h</span>";
        }
        $resumoHtml .= "</div>";

    } else {
        // Formato antigo
        $horasHtml = "";
        $resumoHtml = "";
        foreach ($dias as $key => $nome) {
            $h = isset($horasJson[$key]) ? floatval($horasJson[$key]) : 0;
            $totalNormal += $h;
            $horasHtml .= "<tr><td style='padding:8px;border-bottom:1px solid #e5e7eb;'>$nome</td><td style='padding:8px;border-bottom:1px solid #e5e7eb;text-align:right;font-weight:600;'>{$h}h</td></tr>";
        }
        $totalGeral = $totalNormal;
    }

    // Foto do funcionário
    $fotoUrl = isset($apontamento['funcionario_foto']) && !empty($apontamento['funcionario_foto'])
        ? 'https://j2s.ad/login/backend/' . $apontamento['funcionario_foto']
        : '';

    $fotoHtml = '';
    if ($fotoUrl) {
        $fotoHtml = "<div style='text-align:center;margin-bottom:15px;'>
            <img src='{$fotoUrl}' alt='Foto del empleado' style='width:100px;height:100px;border-radius:50%;object-fit:cover;border:3px solid #16a34a;' />
        </div>";
    }

    // Indicador se é última semana
    $ultimaSemanaHtml = $isUltimaSemana
        ? "<p style='background:#fef3c7;color:#92400e;padding:10px;border-radius:6px;font-size:13px;text-align:center;'>📋 <strong>Última semana del mes</strong> - El informe mensual con valores será enviado a continuación</p>"
        : "<p style='background:#f0fdf4;color:#166534;padding:10px;border-radius:6px;font-size:13px;text-align:center;'>📋 Registro semanal para conferencia (sin valores)</p>";

    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: 'Inter', Arial, sans-serif; line-height: 1.6; color: #1f2937; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #16a34a; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9fafb; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px; }
            .info-box { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 15px; margin: 15px 0; }
            .label { font-size: 12px; color: #6b7280; text-transform: uppercase; margin-bottom: 4px; }
            .value { font-size: 16px; font-weight: 600; color: #1f2937; }
            table { width: 100%; border-collapse: collapse; background: white; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; }
            .signature { margin-top: 20px; text-align: center; }
            .signature img { max-width: 300px; border: 1px solid #e5e7eb; border-radius: 8px; background: white; }
            .badge { display: inline-block; background: #16a34a; color: white; padding: 4px 12px; border-radius: 100px; font-size: 12px; font-weight: 600; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #6b7280; }
            .total-box { background: linear-gradient(135deg, #16a34a 0%, #15803d 100%); color: white; padding: 15px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; margin: 15px 0; }
            .employee-card { background: white; border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; margin: 15px 0; text-align: center; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1 style='margin:0;'>Registro Aprobado ✓</h1>
                <p style='margin:5px 0 0;opacity:0.9;font-size:14px;'>Semana para conferencia</p>
            </div>
            <div class='content'>
                <p><span class='badge'>APROBADO</span></p>
                
                {$ultimaSemanaHtml}
                
                <div class='employee-card'>
                    {$fotoHtml}
                    <div class='label'>Empleado</div>
                    <div class='value' style='font-size:20px;'>{$apontamento['funcionario_nome']}</div>
                </div>
                
                <div class='info-box'>
                    <div class='label'>Obra</div>
                    <div class='value'>{$apontamento['obra_numero']} - {$apontamento['obra_nome']}</div>
                </div>
                
                <div class='info-box'>
                    <div class='label'>Semana</div>
                    <div class='value'>{$apontamento['semana_inicio']}</div>
                </div>
                
                <h3 style='margin-top:25px;'>📋 Detalle de Horas y Valores</h3>
                {$resumoHtml}
                <table style='width:100%;border-collapse:collapse;background:white;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;'>
                    $horasHtml
                </table>

                <h3 style='margin-top:25px;'>💰 Resumen Financiero</h3>
                <table style='width:100%;border-collapse:collapse;background:white;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;margin-bottom:20px;'>
                    <tr style='background:#dcfce7;'>
                        <td style='padding:12px;color:#166534;font-weight:500;'>Horas Normales</td>
                        <td style='padding:12px;text-align:center;color:#166534;'>{$totalNormal}h × €" . number_format($valorNormal, 2) . "</td>
                        <td style='padding:12px;text-align:right;color:#166534;font-weight:600;'>€" . number_format($valorTotalNormal, 2) . "</td>
                    </tr>
                    <tr style='background:#fef3c7;'>
                        <td style='padding:12px;color:#92400e;font-weight:500;'>Horas Extra</td>
                        <td style='padding:12px;text-align:center;color:#92400e;'>{$totalExtra}h × €" . number_format($valorExtra, 2) . "</td>
                        <td style='padding:12px;text-align:right;color:#92400e;font-weight:600;'>€" . number_format($valorTotalExtra, 2) . "</td>
                    </tr>
                    <tr style='background:#e0e7ff;'>
                        <td style='padding:12px;color:#3730a3;font-weight:500;'>Horas Nocturnas</td>
                        <td style='padding:12px;text-align:center;color:#3730a3;'>{$totalNoturna}h × €" . number_format($valorNoturna, 2) . "</td>
                        <td style='padding:12px;text-align:right;color:#3730a3;font-weight:600;'>€" . number_format($valorTotalNoturna, 2) . "</td>
                    </tr>
                </table>

                <div style='background:linear-gradient(135deg,#CE0201 0%,#a00 100%);color:white;padding:20px;border-radius:12px;margin:20px 0;text-align:center;'>
                    <div style='font-size:14px;opacity:0.9;margin-bottom:8px;'>TOTAL SEMANA - {$totalGeral} HORAS</div>
                    <div style='font-size:36px;font-weight:700;'>€" . number_format($valorTotalSemana, 2) . "</div>
                </div>

                <h3 style='margin-top:25px;'>✍️ Firma del Encargado</h3>
                <div class='signature'>
                    <img src='$assinatura' alt='Firma digital' />
                </div>
                
                <div class='info-box' style='margin-top:20px;'>
                    <div class='label'>Aprobado por</div>
                    <div class='value'>{$apontamento['aprovado_por_nome']}</div>
                    <div style='font-size:12px;color:#6b7280;margin-top:4px;'>{$apontamento['aprovado_em']}</div>
                </div>
            </div>
            <div class='footer'>
                <p>Este es un registro semanal para conferencia.</p>
                <p style='color:#16a34a;font-weight:600;'>J2S Enginyeria & Instal·lacions</p>
            </div>
        </div>
    </body>
    </html>
    ";

    // Enviar email semanal
    $enviado = sendEmail($financeEmail, $subject, $html);

    // ========================================
    // 2. SE FOR ÚLTIMA SEMANA, ENVIAR RELATÓRIO MENSAL COM VALORES
    // ========================================
    if ($isUltimaSemana) {
        sendMonthlyReportToFinance($apontamento['obra_id'], $mesAtual, $financeEmail);
    }

    return $enviado;
}

/**
 * Envia relatório mensal consolidado COM VALORES para o financeiro
 * Chamado automaticamente na última semana do mês
 */
function sendMonthlyReportToFinance($obraId, $mes, $emailDestino)
{
    $pdo = getConnection();

    // Buscar valores de hora configurados
    $stmt = $pdo->query("SELECT * FROM config_valores ORDER BY id DESC LIMIT 1");
    $config = $stmt->fetch(PDO::FETCH_ASSOC);

    $valorNormal = isset($config['valor_hora_normal']) ? floatval($config['valor_hora_normal']) : 21.00;
    $valorExtra = isset($config['valor_hora_extra']) ? floatval($config['valor_hora_extra']) : 28.00;
    $valorNoturna = isset($config['valor_hora_noturna']) ? floatval($config['valor_hora_noturna']) : 30.00;

    // Buscar dados da obra e cliente
    $stmt = $pdo->prepare("
        SELECT o.*, c.nome as cliente_nome
        FROM obras o
        LEFT JOIN clientes c ON o.cliente_id = c.id
        WHERE o.id = ?
    ");
    $stmt->execute([$obraId]);
    $obra = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$obra)
        return false;

    // Calcular inicio e fim do mês
    $mesInicio = $mes . '-01';
    $mesFim = date('Y-m-t', strtotime($mesInicio));
    $mesNome = strftime('%B %Y', strtotime($mesInicio));

    // Buscar TODOS os apontamentos aprovados do mês para esta obra
    $stmt = $pdo->prepare("
        SELECT a.*, u.nome as funcionario_nome, u.passaporte as funcionario_passaporte
        FROM apontamentos a
        INNER JOIN usuarios u ON u.id = a.funcionario_id
        WHERE a.obra_id = ? 
        AND a.status IN ('aprovado', 'aprovado_encarregado')
        AND a.semana_inicio >= ?
        AND a.semana_inicio <= ?
        ORDER BY u.nome, a.semana_inicio
    ");
    $stmt->execute([$obraId, $mesInicio, $mesFim]);
    $apontamentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($apontamentos) === 0)
        return false;

    // Agrupar por funcionário e calcular totais
    $funcionarios = [];
    $totaisGeral = ['normal' => 0, 'extra' => 0, 'noturna' => 0, 'total' => 0];

    foreach ($apontamentos as $apt) {
        $funcId = $apt['funcionario_id'];

        if (!isset($funcionarios[$funcId])) {
            $funcionarios[$funcId] = [
                'nome' => $apt['funcionario_nome'],
                'passaporte' => $apt['funcionario_passaporte'],
                'horas_normal' => 0,
                'horas_extra' => 0,
                'horas_noturna' => 0,
            ];
        }

        $horasDiarias = json_decode($apt['horas_diarias'], true);

        if ($horasDiarias) {
            foreach ($horasDiarias as $dia) {
                if (is_array($dia)) {
                    $funcionarios[$funcId]['horas_normal'] += isset($dia['normal']) ? floatval($dia['normal']) : 0;
                    $funcionarios[$funcId]['horas_extra'] += isset($dia['extra']) ? floatval($dia['extra']) : 0;
                    $funcionarios[$funcId]['horas_noturna'] += isset($dia['noturna']) ? floatval($dia['noturna']) : 0;
                } else {
                    $funcionarios[$funcId]['horas_normal'] += floatval($dia);
                }
            }
        }
    }

    // Calcular valores
    foreach ($funcionarios as &$func) {
        $func['valor_normal'] = $func['horas_normal'] * $valorNormal;
        $func['valor_extra'] = $func['horas_extra'] * $valorExtra;
        $func['valor_noturna'] = $func['horas_noturna'] * $valorNoturna;
        $func['valor_total'] = $func['valor_normal'] + $func['valor_extra'] + $func['valor_noturna'];
        $func['horas_total'] = $func['horas_normal'] + $func['horas_extra'] + $func['horas_noturna'];

        $totaisGeral['normal'] += $func['horas_normal'];
        $totaisGeral['extra'] += $func['horas_extra'];
        $totaisGeral['noturna'] += $func['horas_noturna'];
        $totaisGeral['total'] += $func['horas_total'];
    }

    $valorTotalNormal = $totaisGeral['normal'] * $valorNormal;
    $valorTotalExtra = $totaisGeral['extra'] * $valorExtra;
    $valorTotalNoturna = $totaisGeral['noturna'] * $valorNoturna;
    $valorTotal = $valorTotalNormal + $valorTotalExtra + $valorTotalNoturna;

    // Construir tabela de funcionários
    $funcionariosHtml = "";
    foreach ($funcionarios as $func) {
        $funcionariosHtml .= "<tr style='border-bottom:1px solid #e5e7eb;'>
            <td style='padding:10px 8px;'>
                <div style='font-weight:500;'>{$func['nome']}</div>
                <div style='font-size:11px;color:#6b7280;'>{$func['passaporte']}</div>
            </td>
            <td style='padding:10px 8px;text-align:center;color:#166534;'>{$func['horas_normal']}h</td>
            <td style='padding:10px 8px;text-align:center;color:#92400e;'>{$func['horas_extra']}h</td>
            <td style='padding:10px 8px;text-align:center;color:#3730a3;'>{$func['horas_noturna']}h</td>
            <td style='padding:10px 8px;text-align:center;font-weight:600;'>{$func['horas_total']}h</td>
            <td style='padding:10px 8px;text-align:right;font-weight:600;color:#16a34a;'>€" . number_format($func['valor_total'], 2) . "</td>
        </tr>";
    }

    $clienteNome = $obra['cliente_nome'] ?: 'N/A';
    $subject = "💰 INFORME MENSUAL - {$obra['numero']} - {$mes} - TOTAL €" . number_format($valorTotal, 2);

    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: 'Inter', Arial, sans-serif; line-height: 1.6; color: #1f2937; }
            .container { max-width: 700px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #16a34a 0%, #15803d 100%); color: white; padding: 25px; text-align: center; border-radius: 12px 12px 0 0; }
            .content { background: #f9fafb; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 12px 12px; }
            .info-box { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 15px; margin: 15px 0; }
            .label { font-size: 12px; color: #6b7280; text-transform: uppercase; margin-bottom: 4px; }
            .value { font-size: 16px; font-weight: 600; color: #1f2937; }
            table { width: 100%; border-collapse: collapse; background: white; border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden; }
            th { padding: 12px 8px; text-align: center; font-weight: 600; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #6b7280; }
            .total-box { background: linear-gradient(135deg, #CE0201 0%, #a00 100%); color: white; padding: 20px; border-radius: 12px; margin: 20px 0; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1 style='margin:0;font-size:24px;'>💰 INFORME MENSUAL</h1>
                <p style='margin:8px 0 0;opacity:0.95;font-size:16px;'>Listo para facturación</p>
            </div>
            <div class='content'>
                <div style='background:#f0fdf4;border:2px solid #16a34a;border-radius:8px;padding:16px;margin-bottom:20px;text-align:center;'>
                    <div style='font-size:14px;color:#166534;margin-bottom:4px;'>TOTAL A FACTURAR</div>
                    <div style='font-size:36px;font-weight:700;color:#16a34a;'>€" . number_format($valorTotal, 2) . "</div>
                </div>
                
                <div style='display:flex;gap:15px;flex-wrap:wrap;margin-bottom:20px;'>
                    <div class='info-box' style='flex:1;min-width:150px;'>
                        <div class='label'>Obra</div>
                        <div class='value'>{$obra['numero']}</div>
                        <div style='font-size:13px;color:#6b7280;'>{$obra['nome']}</div>
                    </div>
                    <div class='info-box' style='flex:1;min-width:150px;'>
                        <div class='label'>Cliente</div>
                        <div class='value'>{$clienteNome}</div>
                    </div>
                    <div class='info-box' style='flex:1;min-width:150px;'>
                        <div class='label'>Período</div>
                        <div class='value'>{$mes}</div>
                        <div style='font-size:13px;color:#6b7280;'>" . count($funcionarios) . " empleados</div>
                    </div>
                </div>

                <h3 style='margin-top:25px;margin-bottom:15px;'>👥 Detalle por Empleado</h3>
                <table>
                    <thead>
                        <tr style='background:#f8f9fa;'>
                            <th style='text-align:left;border-bottom:2px solid #e5e7eb;'>Empleado</th>
                            <th style='border-bottom:2px solid #e5e7eb;background:#dcfce7;color:#166534;'>Normal<br><span style='font-size:10px;font-weight:400;'>€{$valorNormal}/h</span></th>
                            <th style='border-bottom:2px solid #e5e7eb;background:#fef3c7;color:#92400e;'>Extra<br><span style='font-size:10px;font-weight:400;'>€{$valorExtra}/h</span></th>
                            <th style='border-bottom:2px solid #e5e7eb;background:#e0e7ff;color:#3730a3;'>Nocturna<br><span style='font-size:10px;font-weight:400;'>€{$valorNoturna}/h</span></th>
                            <th style='border-bottom:2px solid #e5e7eb;'>Total h</th>
                            <th style='border-bottom:2px solid #e5e7eb;text-align:right;'>Valor €</th>
                        </tr>
                    </thead>
                    <tbody>
                        {$funcionariosHtml}
                    </tbody>
                </table>

                <h3 style='margin-top:25px;margin-bottom:15px;'>💰 Resumen de Valores</h3>
                <table>
                    <tr style='background:#dcfce7;'>
                        <td style='padding:12px;color:#166534;font-weight:500;'>Horas Normales (8-17h)</td>
                        <td style='padding:12px;text-align:center;color:#166534;'>{$totaisGeral['normal']}h × €" . number_format($valorNormal, 2) . "</td>
                        <td style='padding:12px;text-align:right;color:#166534;font-weight:600;'>€" . number_format($valorTotalNormal, 2) . "</td>
                    </tr>
                    <tr style='background:#fef3c7;'>
                        <td style='padding:12px;color:#92400e;font-weight:500;'>Horas Extra (17-22h)</td>
                        <td style='padding:12px;text-align:center;color:#92400e;'>{$totaisGeral['extra']}h × €" . number_format($valorExtra, 2) . "</td>
                        <td style='padding:12px;text-align:right;color:#92400e;font-weight:600;'>€" . number_format($valorTotalExtra, 2) . "</td>
                    </tr>
                    <tr style='background:#e0e7ff;'>
                        <td style='padding:12px;color:#3730a3;font-weight:500;'>Horas Nocturnas (22-6h)</td>
                        <td style='padding:12px;text-align:center;color:#3730a3;'>{$totaisGeral['noturna']}h × €" . number_format($valorNoturna, 2) . "</td>
                        <td style='padding:12px;text-align:right;color:#3730a3;font-weight:600;'>€" . number_format($valorTotalNoturna, 2) . "</td>
                    </tr>
                </table>

                <div class='total-box' style='text-align:center;'>
                    <div style='font-size:14px;opacity:0.9;margin-bottom:8px;'>TOTAL GENERAL - {$totaisGeral['total']} HORAS</div>
                    <div style='font-size:40px;font-weight:700;'>€" . number_format($valorTotal, 2) . "</div>
                </div>
            </div>
            <div class='footer'>
                <p>Este es un informe mensual automático consolidando todas las semanas aprobadas.</p>
                <p style='color:#16a34a;font-weight:600;'>J2S Enginyeria & Instal·lacions</p>
            </div>
        </div>
    </body>
    </html>
    ";

    return sendEmail($emailDestino, $subject, $html);
}

/**
 * Notifica funcionário sobre rejeição
 */
function sendRejectionNotification($funcionarioEmail, $funcionarioNome, $obraNumero, $semana, $motivo)
{
    $subject = "Registro de horas rechazado - Semana $semana";

    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: 'Inter', Arial, sans-serif; line-height: 1.6; color: #1f2937; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #dc2626; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9fafb; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px; }
            .info-box { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 15px; margin: 15px 0; }
            .reason-box { background: #fef2f2; border: 1px solid #dc2626; border-radius: 8px; padding: 15px; margin: 15px 0; }
            .label { font-size: 12px; color: #6b7280; text-transform: uppercase; }
            .value { font-size: 16px; font-weight: 600; color: #1f2937; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #6b7280; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1 style='margin:0;'>Registro Rechazado</h1>
            </div>
            <div class='content'>
                <p>Hola $funcionarioNome,</p>
                <p>Su registro de horas ha sido rechazado y requiere corrección.</p>
                
                <div class='info-box'>
                    <div class='label'>Obra</div>
                    <div class='value'>$obraNumero</div>
                </div>
                
                <div class='info-box'>
                    <div class='label'>Semana</div>
                    <div class='value'>$semana</div>
                </div>
                
                <div class='reason-box'>
                    <div class='label'>Motivo del rechazo</div>
                    <div class='value'>$motivo</div>
                </div>
                
                <p>Por favor, acceda al sistema para revisar y corregir su registro.</p>
            </div>
            <div class='footer'>
                <p>Este es un mensaje automático del Sistema de Control Horario.</p>
            </div>
        </div>
    </body>
    </html>
    ";

    return sendEmail($funcionarioEmail, $subject, $html);
}

/**
 * Notifica Admin/RH que há registro pendente de aprovação final
 */
function sendAdminNotification($apontamento, $adminEmail)
{
    $subject = "Registro pendiente de aprobación final - {$apontamento['funcionario_nome']}";

    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: 'Inter', Arial, sans-serif; line-height: 1.6; color: #1f2937; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #f59e0b; color: white; padding: 20px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9fafb; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px; }
            .info-box { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 15px; margin: 15px 0; }
            .label { font-size: 12px; color: #6b7280; text-transform: uppercase; }
            .value { font-size: 16px; font-weight: 600; color: #1f2937; }
            .badge { display: inline-block; background: #f59e0b; color: white; padding: 4px 12px; border-radius: 100px; font-size: 12px; font-weight: 600; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #6b7280; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1 style='margin:0;'>Pendiente de Aprobación Final</h1>
            </div>
            <div class='content'>
                <p><span class='badge'>APROBADO POR ENCARGADO</span></p>
                <p>Un registro de horas ha sido aprobado por el encargado y está pendiente de su aprobación final.</p>
                
                <div class='info-box'>
                    <div class='label'>Empleado</div>
                    <div class='value'>{$apontamento['funcionario_nome']}</div>
                </div>
                
                <div class='info-box'>
                    <div class='label'>Obra</div>
                    <div class='value'>{$apontamento['obra_numero']} - {$apontamento['obra_nome']}</div>
                </div>
                
                <div class='info-box'>
                    <div class='label'>Semana</div>
                    <div class='value'>{$apontamento['semana_inicio']}</div>
                </div>
                
                <div class='info-box'>
                    <div class='label'>Aprobado por (Encargado)</div>
                    <div class='value'>{$apontamento['aprovado_por_nome']}</div>
                    <div style='font-size:12px;color:#6b7280;'>{$apontamento['aprovado_em']}</div>
                </div>
                
                <p>Por favor, acceda al sistema para revisar y dar la aprobación final.</p>
            </div>
            <div class='footer'>
                <p>Este es un mensaje automático del Sistema de Control Horario.</p>
            </div>
        </div>
    </body>
    </html>
    ";

    return sendEmail($adminEmail, $subject, $html);
}

/**
 * Email final após aprovação do Admin/RH (para J2S)
 */
function sendFinalApproval($apontamento, $assinatura, $emailDestino)
{
    $subject = "✓ APROBACIÓN FINAL - {$apontamento['funcionario_nome']} - Semana {$apontamento['semana_inicio']}";

    // Montar URL completa da foto se existir
    $fotoUrl = isset($apontamento['funcionario_foto']) && !empty($apontamento['funcionario_foto'])
        ? 'https://j2s.ad/login/backend/' . $apontamento['funcionario_foto']
        : '';

    $fotoHtml = '';
    if ($fotoUrl) {
        $fotoHtml = "<div style='text-align:center;margin-bottom:15px;'>
            <img src='{$fotoUrl}' alt='Foto del empleado' style='width:100px;height:100px;border-radius:50%;object-fit:cover;border:3px solid #16a34a;' />
        </div>";
    }

    $horasJson = json_decode($apontamento['horas_diarias'], true);
    $dias = ['mon' => 'Lunes', 'tue' => 'Martes', 'wed' => 'Miércoles', 'thu' => 'Jueves', 'fri' => 'Viernes', 'sat' => 'Sábado'];

    // Verificar formato e calcular totais
    $isNewFormat = false;
    if ($horasJson && is_array($horasJson)) {
        $firstValue = reset($horasJson);
        $isNewFormat = is_array($firstValue);
    }

    $totalNormal = 0;
    $totalExtra = 0;
    $totalNoturna = 0;
    $horasHtml = '';

    if ($isNewFormat) {
        $horasHtml = "<tr style='background:#f8f9fa;'>
            <th style='padding:8px;text-align:left;'>Día</th>
            <th style='padding:8px;text-align:center;background:#dcfce7;color:#166534;'>Normal</th>
            <th style='padding:8px;text-align:center;background:#fef3c7;color:#92400e;'>Extra</th>
            <th style='padding:8px;text-align:center;background:#e0e7ff;color:#3730a3;'>Noct.</th>
        </tr>";

        foreach ($dias as $key => $nome) {
            $dayData = isset($horasJson[$key]) ? $horasJson[$key] : array('normal' => 0, 'extra' => 0, 'noturna' => 0);
            $normal = isset($dayData['normal']) ? floatval($dayData['normal']) : 0;
            $extra = isset($dayData['extra']) ? floatval($dayData['extra']) : 0;
            $noturna = isset($dayData['noturna']) ? floatval($dayData['noturna']) : 0;

            $totalNormal += $normal;
            $totalExtra += $extra;
            $totalNoturna += $noturna;

            $horasHtml .= "<tr style='border-bottom:1px solid #e5e7eb;'>
                <td style='padding:6px 8px;'>{$nome}</td>
                <td style='padding:6px 8px;text-align:center;'>{$normal}h</td>
                <td style='padding:6px 8px;text-align:center;'>{$extra}h</td>
                <td style='padding:6px 8px;text-align:center;'>{$noturna}h</td>
            </tr>";
        }

        $totalGeral = $totalNormal + $totalExtra + $totalNoturna;
        $horasHtml .= "<tr style='background:#f8f9fa;font-weight:600;'>
            <td style='padding:8px;'>TOTAL</td>
            <td style='padding:8px;text-align:center;color:#166534;'>{$totalNormal}h</td>
            <td style='padding:8px;text-align:center;color:#92400e;'>{$totalExtra}h</td>
            <td style='padding:8px;text-align:center;color:#3730a3;'>{$totalNoturna}h</td>
        </tr>";
    } else {
        foreach ($dias as $key => $nome) {
            $h = isset($horasJson[$key]) ? floatval($horasJson[$key]) : 0;
            $totalNormal += $h;
            $horasHtml .= "<tr><td style='padding:8px;border-bottom:1px solid #e5e7eb;'>{$nome}</td><td style='padding:8px;text-align:right;font-weight:600;'>{$h}h</td></tr>";
        }
        $totalGeral = $totalNormal;
    }

    $encarregadoNome = isset($apontamento['encarregado_nome']) ? $apontamento['encarregado_nome'] : $apontamento['aprovado_por_nome'];

    $html = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: 'Inter', Arial, sans-serif; line-height: 1.6; color: #1f2937; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #16a34a 0%, #15803d 100%); color: white; padding: 25px; text-align: center; border-radius: 8px 8px 0 0; }
            .content { background: #f9fafb; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px; }
            .employee-card { background: white; border: 1px solid #e5e7eb; border-radius: 12px; padding: 20px; margin: 15px 0; text-align: center; }
            .info-box { background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 15px; margin: 15px 0; }
            .label { font-size: 12px; color: #6b7280; text-transform: uppercase; margin-bottom: 4px; }
            .value { font-size: 16px; font-weight: 600; color: #1f2937; }
            table { width: 100%; border-collapse: collapse; background: white; border: 1px solid #e5e7eb; border-radius: 8px; }
            .signature { margin-top: 20px; text-align: center; }
            .signature img { max-width: 200px; border: 1px solid #e5e7eb; border-radius: 8px; background: white; }
            .badge { display: inline-block; background: #16a34a; color: white; padding: 4px 12px; border-radius: 100px; font-size: 12px; font-weight: 600; }
            .total-box { background: linear-gradient(135deg, #16a34a 0%, #15803d 100%); color: white; padding: 15px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; margin: 15px 0; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #6b7280; }
            .approvals-box { display: flex; gap: 15px; margin-top: 20px; }
            .approval-item { flex: 1; background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 15px; text-align: center; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1 style='margin:0;'>✓ APROBACIÓN FINAL</h1>
                <p style='margin:10px 0 0 0;opacity:0.9;'>Registro completamente aprobado</p>
            </div>
            <div class='content'>
                <p><span class='badge'>APROBADO</span></p>
                
                <div class='employee-card'>
                    {$fotoHtml}
                    <div class='label'>Empleado</div>
                    <div class='value' style='font-size:20px;'>{$apontamento['funcionario_nome']}</div>
                </div>
                
                <div class='info-box'>
                    <div class='label'>Obra</div>
                    <div class='value'>{$apontamento['obra_numero']} - {$apontamento['obra_nome']}</div>
                </div>
                
                <div class='info-box'>
                    <div class='label'>Semana</div>
                    <div class='value'>{$apontamento['semana_inicio']}</div>
                </div>
                
                <h3 style='margin-top:25px;'>Detalle de Horas</h3>
                <table>
                    {$horasHtml}
                </table>
                
                <div class='total-box'>
                    <span style='font-weight:600;'>TOTAL GENERAL</span>
                    <span style='font-size:24px;font-weight:700;'>{$totalGeral}h</span>
                </div>
                
                <h3 style='margin-top:25px;'>Aprobaciones</h3>
                <div class='approvals-box'>
                    <div class='approval-item'>
                        <div class='label'>Encargado</div>
                        <div class='value'>{$encarregadoNome}</div>
                        <div class='signature'>
                            <img src='{$apontamento['assinatura_base64']}' alt='Firma encargado' style='max-width:150px;' />
                        </div>
                    </div>
                    <div class='approval-item'>
                        <div class='label'>Admin/RH</div>
                        <div class='value'>{$apontamento['aprovado_admin_por_nome']}</div>
                        <div class='signature'>
                            <img src='{$assinatura}' alt='Firma admin' style='max-width:150px;' />
                        </div>
                    </div>
                </div>
            </div>
            <div class='footer'>
                <p>Este es un informe automático del Sistema de Control Horario J2S.</p>
            </div>
        </div>
    </body>
    </html>
    ";

    return sendEmail($emailDestino, $subject, $html);
}
